package com.example.burguerexpresso;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Pedido extends AppCompatActivity {

    private TextView tituloResumo, txtResumo;
    private Button btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pedido);


        tituloResumo = findViewById(R.id.tituloResumo);
        txtResumo = findViewById(R.id.txtResumo);
        btnVoltar = findViewById(R.id.btnVoltar);


        Intent intent = getIntent();
        String nome = intent.getStringExtra("nome");
        String lanche = intent.getStringExtra("lanche");
        String adicionais = intent.getStringExtra("adicionais");
        int quantidade = intent.getIntExtra("quantidade", 0);
        double precoLanche = intent.getDoubleExtra("precoLanche", 0.0);
        double precoTotal = intent.getDoubleExtra("precoTotal", 0.0);

        String resumo = "Nome: " + nome + "\n";

        if (quantidade > 0) {
            resumo += "Lanche: " + lanche + "\n";
            resumo += "Adicionais: " + (adicionais.isEmpty() ? "Nenhum" : adicionais.trim()) + "\n";
            resumo += "Quantidade: " + quantidade + "\n";
            resumo += String.format("Preço unitário: R$ %.2f\n", precoLanche);
            resumo += String.format("Total: R$ %.2f", precoTotal);
        } else {
            resumo += "Para seguir com o pedido, insira a quantidade. Volte para a página de pedidos!\n";
        }

        txtResumo.setText(resumo);


        btnVoltar.setOnClickListener(v -> finish());
    }
}
