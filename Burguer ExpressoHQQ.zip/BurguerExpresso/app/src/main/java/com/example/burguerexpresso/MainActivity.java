package com.example.burguerexpresso;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editNome;
    private CheckBox checkBacon, checkQueijo, checkOnion;
    private RadioGroup radioGroupLanches;
    private TextView txtQuantidade;

    private int quantidade = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        editNome = findViewById(R.id.editTextText2);
        checkBacon = findViewById(R.id.checkBox);
        checkQueijo = findViewById(R.id.checkBox2);
        checkOnion = findViewById(R.id.checkBox3);
        radioGroupLanches = findViewById(R.id.radioGroupLanches);
        txtQuantidade = findViewById(R.id.quantidade);
        ImageButton btnMenos = findViewById(R.id.imageButton5);
        ImageButton btnMais = findViewById(R.id.imageButton6);
        Button btnEnviarPedido = findViewById(R.id.btnEnviarPedido);


        btnMais.setOnClickListener(view -> {
            quantidade++;
            txtQuantidade.setText(String.valueOf(quantidade));
        });

        btnMenos.setOnClickListener(view -> {
            if (quantidade > 0) {
                quantidade--;
                txtQuantidade.setText(String.valueOf(quantidade));
            }
        });


        btnEnviarPedido.setOnClickListener(view -> {
            String nome = editNome.getText().toString();
            if (nome.isEmpty()) {
                Toast.makeText(this, "Digite seu nome!", Toast.LENGTH_SHORT).show();
                return;
            }

            int idSelecionado = radioGroupLanches.getCheckedRadioButtonId();
            if (idSelecionado == -1) {
                Toast.makeText(this, "Selecione um lanche!", Toast.LENGTH_SHORT).show();
                return;
            }

            double precoLanche = 0.0;
            String lancheSelecionado = "";


            if (idSelecionado == R.id.radioBurguerSimples) {
                precoLanche = 18.00;
                lancheSelecionado = "Burger Simples";
            } else if (idSelecionado == R.id.radioOnionBurguer) {
                precoLanche = 24.50;
                lancheSelecionado = "Onion Burguer";
            } else if (idSelecionado == R.id.radioCheddarBurguer) {
                precoLanche = 22.00;
                lancheSelecionado = "Cheddar Burguer";
            } else if (idSelecionado == R.id.radioDoubleBurguer) {
                precoLanche = 28.00;
                lancheSelecionado = "Double Burguer";
            } else {
                Toast.makeText(this, "Erro ao identificar o lanche!", Toast.LENGTH_SHORT).show();
                return;
            }

            StringBuilder adicionais = new StringBuilder();
            if (checkBacon.isChecked()) {
                precoLanche += 2.00;
                adicionais.append("Bacon ");
            }
            if (checkQueijo.isChecked()) {
                precoLanche += 2.00;
                adicionais.append("Queijo ");
            }
            if (checkOnion.isChecked()) {
                precoLanche += 3.00;
                adicionais.append("Onion Rings ");
            }

            double precoTotal = precoLanche * quantidade;

            Intent intent = new Intent(this, Pedido.class);
            intent.putExtra("nome", nome);
            intent.putExtra("lanche", lancheSelecionado);
            intent.putExtra("adicionais", adicionais.toString().trim());
            intent.putExtra("quantidade", quantidade);
            intent.putExtra("precoLanche", precoLanche);
            intent.putExtra("precoTotal", precoTotal);

            startActivity(intent);
        });
    }
}
